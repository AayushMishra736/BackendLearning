package com.example.TacosCloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TacosCloudApplication {

	public static void main(String[] args) {
		SpringApplication.run(TacosCloudApplication.class, args);
	}

}
